version_info = (0, 1, 2)
version = '.'.join(map(str, version_info))
