# system imports
from threading import RLock
from types import ModuleType

# library imports

# application imports

_settings_lock = RLock()
_settings = None


class _Settings(object):
    """ Settings object """

    def __init__(self, config, parent=None):
        self.__config = config
        self.__parent = parent

    def __getattr__(self, name):
        """ Returns attributes based on the values in the internal config
        dictionary. With a config dictionary like

            {"A": "a"}

        then

            settings.A

        evaluate to "a".

        :param name: the name of the attribute to get
        :return: the value of the attribute
        :raises: AttributeError if the name is not in the config dictionary
          or is not UPPER_CASE
        """
        if not name.isupper():
            raise AttributeError("Settings must be UPPER_CASE.")

        if name not in self.__config and self.__parent:
            value = getattr(self.__parent, name)
            return value

        elif name in self.__config:
            value = self.__config[name]
            if isinstance(value, dict):
                value = _Settings(value, parent=self)
            setattr(self, name, value)
            return value

        raise AttributeError()

    def __str__(self):
        return str(self.__config)


def get_settings():
    """
    Returns the current _Settings object.

    :return: an instance of _Settings
    """
    global _settings
    with _settings_lock:
        if not _settings:
            import settings
            set_settings(settings)
        return _settings


def set_settings(settings_dict_or_module):
    """
    Set the current _Settings object, based on an input dictionary of module.

    :param settings_dict_or_module: a dict or a python module
    :return: an instance of _Settings
    """
    global _settings
    with _settings_lock:
        data = {}
        if isinstance(settings_dict_or_module, dict):
            data = dict((name, settings_dict_or_module[name])
                        for name in settings_dict_or_module.keys()
                        if name == name.upper() and
                        not (name.startswith('__') or name.endswith('__')))
        elif isinstance(settings_dict_or_module, ModuleType):
            data = dict((name, getattr(settings_dict_or_module, name))
                        for name in dir(settings_dict_or_module)
                        if name == name.upper() and
                        not (name.startswith('__') or name.endswith('__')))
        _settings = _Settings(data)
        return _settings
